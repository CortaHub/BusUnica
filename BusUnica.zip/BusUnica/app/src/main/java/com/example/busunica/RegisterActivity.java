package com.example.busunica;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import org.jetbrains.annotations.NotNull;

public class RegisterActivity extends AppCompatActivity {

    FirebaseAuth mAuth;
    Button reg,pro,back;
    EditText pwsd,cpwsd,mail;
    CardView A,B;
    String email,pass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if(currentUser != null){
            startActivity(new Intent(RegisterActivity.this,VerifyActivity.class));
            finish();
        }
        setContentView(R.layout.activity_register);
        A=findViewById(R.id.cardview6);
        B=findViewById(R.id.cardView3);
        A.setVisibility(View.INVISIBLE);
        B.setVisibility(View.VISIBLE);
        pro=findViewById(R.id.reg_proceed);
        reg=findViewById(R.id.reg_create);
        pwsd=findViewById(R.id.reg_pwsd);
        cpwsd=findViewById(R.id.reg_confirmpwsd);
        mail=findViewById(R.id.reg_email);
        back=findViewById(R.id.reg_back);
        pro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                proceed();
            }
        });
        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SignUp();
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                back();
            }
        });
    }
    public void proceed(){
        A.setVisibility(View.VISIBLE);
        B.setVisibility(View.INVISIBLE);
    }
    public void SignUp(){
        if (!isvalidform()){
            return;
        }
        email=mail.getText().toString();
        pass=pwsd.getText().toString();
        mAuth.createUserWithEmailAndPassword(email,pass).addOnCompleteListener(this,new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull @NotNull Task<AuthResult> task) {
                if(task.isSuccessful()) {
                    Toast.makeText(getApplicationContext(),"Registration Successful",Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(RegisterActivity.this,VerifyActivity.class));
                    finish();
                }
                else{
                    Log.d("RFAILED",task.getException().toString());
                    Toast.makeText(getApplicationContext(),"Registration Failed",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    public boolean isvalidform(){
        boolean valid=true;
        if(TextUtils.isEmpty(mail.getText())) {
            Toast.makeText(getApplicationContext(), "Email is required", Toast.LENGTH_SHORT).show();
            mail.setError("Required");
            valid=false;
        }
        if(TextUtils.isEmpty(pwsd.getText()) || TextUtils.isEmpty(cpwsd.getText())){
            Toast.makeText(getApplicationContext(),"Password is required",Toast.LENGTH_SHORT).show();
            if(pwsd.getText().toString().length()==0)
                pwsd.setError("Required");
            else
                cpwsd.setError("Required");
            valid=false;
        }
        return valid;
    }
    public void back(){
        B.setVisibility(View.VISIBLE);
        A.setVisibility(View.INVISIBLE);
    }
}