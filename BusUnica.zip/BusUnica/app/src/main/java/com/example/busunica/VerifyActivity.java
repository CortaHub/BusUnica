package com.example.busunica;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class VerifyActivity extends AppCompatActivity {

    FirebaseAuth mAuth;
    FirebaseUser cUser;
    TextView msg,msgaf;
    Button verify,Continue;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        cUser=mAuth.getCurrentUser();
        if(cUser.isEmailVerified()){
            startActivity(new Intent(VerifyActivity.this,FinalActivity.class));
            finish();
        }
        else{
            verify=findViewById(R.id.verify_link);
            Continue=findViewById(R.id.verify_continue);
            msg=findViewById(R.id.verify_msg);
            msgaf=findViewById(R.id.afterconfirm_verify);
            msg.setVisibility(View.INVISIBLE);
            msgaf.setVisibility(View.INVISIBLE);
            verify.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    verifylink();
                }
            });
            Continue.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    aVerify();
                }
            });
        }
        setContentView(R.layout.activity_verify);
    }

    public void verifylink(){
        mAuth.getCurrentUser().sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull @org.jetbrains.annotations.NotNull Task<Void> task) {
                if(task.isSuccessful()) {
                    msg.setVisibility(View.VISIBLE);
                    msgaf.setVisibility(View.VISIBLE);
                }
                else{
                    Log.d("VF","Verification email not sent");
                }
            }
        });
    }
    public void aVerify(){
        if(cUser.isEmailVerified()){
            startActivity(new Intent(VerifyActivity.this,FinalActivity.class));
            finish();
        }
        else{
            Toast.makeText(getApplicationContext(),"Email is not yet verified",Toast.LENGTH_SHORT).show();
        }
    }
}